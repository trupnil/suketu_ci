 <!-- Core CSS - Include with every page -->
    <link href="<?php echo base_url() ?>admin/assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="<?php echo base_url() ?>admin/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo base_url() ?>admin/assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="<?php echo base_url() ?>admin/assets/css/style.css" rel="stylesheet" />
    <link href="<?php echo base_url() ?>admin/assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="<?php echo base_url() ?>admin/assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
  