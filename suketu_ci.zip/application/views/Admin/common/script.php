  <!-- Core Scripts - Include with every page -->
    <script src="<?php echo base_url() ?>admin/assets/plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url() ?>admin/assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>admin/assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url() ?>admin/assets/plugins/pace/pace.js"></script>
    <script src="<?php echo base_url() ?>admin/assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="<?php echo base_url() ?>admin/assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="<?php echo base_url() ?>admin/assets/plugins/morris/morris.js"></script>
    <script src="<?php echo base_url() ?>admin/assets/scripts/dashboard-demo.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>